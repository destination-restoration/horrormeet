HORRORMEET LOGO PACK (Sept 2026)

COLORS
  Red        #B3121B   (RGB 179, 18, 27)
  Deep red   #5C0A10   (the drop shadow behind the letters)
  Black      #0B0B0E
  Bone white #F3EDE4   (the letters)

FONTS (both free, Google Fonts, SIL Open Font License; TTFs included)
  Frijole  = the HORRORMEET wordmark and the HM mark
  Rye      = the tagline and small caps

FOR 3D PRINTING / CNC / LASER
  Use the SVG-vector folder. Everything in there is real outlines (no live text, no fonts needed).
  *-ONE-COLOR-outline.svg files are plain black shapes on nothing: import straight into your slicer
  or Tinkercad / Fusion and extrude. Frijole has a lot of tiny chips and flecks around the letters;
  if they print as loose specks, add a small offset or drop features under ~0.8 mm.
  HorrorMeet-CARD-front / back are credit-card size (85.6 x 54 mm, rounded corners) ready to go.
  The QR code goes to horrormeet.com/join (error correction H, so it still scans when embossed or partly worn).

TAGLINE: beyond the limits of your group chat.
URL: horrormeet.com  ·  IG @horrormeetapp  ·  YouTube @HorrorMeet
